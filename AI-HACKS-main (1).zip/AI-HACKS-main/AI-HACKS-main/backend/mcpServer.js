// Exposes this app's brain (Google Places lookup + Claude recommendation/
// narration writing) as MCP tools. Connect this to Poke (poke.com/kitchen)
// and you can text Poke things like "recommend a coffee shop near 4th and
// University in Berkeley" and it'll call straight into the same logic the
// voice app uses — Poke just delivers the result as a text instead of audio.
//
// Poke has no GPS, so every tool takes a free-text location and geocodes it
// server-side, instead of taking lat/lng like the frontend does.

import { McpServer } from "@modelcontextprotocol/sdk/server/mcp.js";
import { StreamableHTTPServerTransport } from "@modelcontextprotocol/sdk/server/streamableHttp.js";
import { z } from "zod";
import { geocodeLocation, searchNearbyPlaces, CATEGORIES } from "./googlePlaces.js";
import { recommendFromPlaces } from "./recommend.js";
import { findNearbyWikiPlaces } from "./wikipedia.js";
import { narratePlace } from "./narrate.js";

function buildMcpServer() {
  const server = new McpServer({ name: "wayfarer", version: "1.0.0" });

  server.tool(
    "recommend_nearby",
    "Recommend nearby restaurants, bars/cafes, or things to do near a described location. " +
      "Use this whenever the user asks for food, drink, or activity suggestions near somewhere.",
    {
      location: z.string().describe('A place description, e.g. "Telegraph and Dwight, Berkeley" or an address'),
      category: z.enum(["food", "drink", "things_to_do"]).describe("What kind of place to recommend"),
    },
    async ({ location, category }) => {
      try {
        const { lat, lng, formattedAddress } = await geocodeLocation(location);
        const places = await searchNearbyPlaces({ lat, lng, category, radiusMeters: 1200 });
        const text = await recommendFromPlaces({ category, places, locationLabel: formattedAddress });
        return { content: [{ type: "text", text }] };
      } catch (err) {
        return { content: [{ type: "text", text: `Couldn't get recommendations: ${err.message}` }], isError: true };
      }
    }
  );

  server.tool(
    "narrate_location",
    "Tell the story behind a notable place or landmark near a described location, using whatever " +
      "geotagged Wikipedia article is closest. Use this when the user wants history or background, not recommendations.",
    {
      location: z.string().describe('A place description, e.g. "Sather Tower, Berkeley" or an address'),
    },
    async ({ location }) => {
      try {
        const { lat, lng } = await geocodeLocation(location);
        const places = await findNearbyWikiPlaces({ lat, lng, radiusMeters: 800, limit: 5 });
        if (!places.length) {
          return { content: [{ type: "text", text: "Nothing with a Wikipedia entry that close — try a bigger landmark nearby." }] };
        }
        const top = places[0];
        const script = await narratePlace({ placeName: top.title, extract: top.extract, distanceMeters: top.distanceMeters });
        return { content: [{ type: "text", text: script }] };
      } catch (err) {
        return { content: [{ type: "text", text: `Couldn't put together a story: ${err.message}` }], isError: true };
      }
    }
  );

  return server;
}

/**
 * Mounts a stateless streamable-HTTP MCP endpoint at POST /mcp.
 * Stateless = a fresh server/transport per request, which is the simplest
 * option and fine for this use case (no long-lived sessions needed).
 */
export function registerMcpRoutes(app) {
  app.post("/mcp", async (req, res) => {
    try {
      const server = buildMcpServer();
      const transport = new StreamableHTTPServerTransport({ sessionIdGenerator: undefined });
      res.on("close", () => {
        transport.close();
        server.close();
      });
      await server.connect(transport);
      await transport.handleRequest(req, res, req.body);
    } catch (err) {
      console.error("MCP error:", err);
      if (!res.headersSent) {
        res.status(500).json({ jsonrpc: "2.0", error: { code: -32603, message: "Internal MCP error" }, id: null });
      }
    }
  });

  // GET/DELETE aren't used in stateless mode, but the MCP spec expects a
  // response rather than a hang if a client probes them.
  app.get("/mcp", (_req, res) => res.status(405).json({ error: "Method not allowed (stateless server)" }));
  app.delete("/mcp", (_req, res) => res.status(405).json({ error: "Method not allowed (stateless server)" }));
}
