const WIKI_API = "https://en.wikipedia.org/w/api.php";

/**
 * Same logic as frontend/src/lib/wikipedia.js, duplicated here because MCP
 * tools run server-side (no browser CORS concerns, no shared bundle with
 * the frontend). Keep both in sync if you change the narration radius logic.
 */
export async function findNearbyWikiPlaces({ lat, lng, radiusMeters = 800, limit = 5 }) {
  const geoParams = new URLSearchParams({
    action: "query",
    list: "geosearch",
    gscoord: `${lat}|${lng}`,
    gsradius: String(Math.min(radiusMeters, 10000)),
    gslimit: String(limit),
    format: "json",
    origin: "*",
  });

  const geoRes = await fetch(`${WIKI_API}?${geoParams}`);
  if (!geoRes.ok) throw new Error(`Wikipedia geosearch failed: ${geoRes.status}`);
  const geoData = await geoRes.json();
  const results = geoData?.query?.geosearch ?? [];
  if (results.length === 0) return [];

  const pageIds = results.map((r) => r.pageid).join("|");
  const extractParams = new URLSearchParams({
    action: "query",
    prop: "extracts",
    exintro: "true",
    explaintext: "true",
    exsentences: "6",
    pageids: pageIds,
    format: "json",
    origin: "*",
  });

  const extractRes = await fetch(`${WIKI_API}?${extractParams}`);
  if (!extractRes.ok) throw new Error(`Wikipedia extracts failed: ${extractRes.status}`);
  const extractData = await extractRes.json();
  const pages = extractData?.query?.pages ?? {};

  return results
    .map((r) => ({
      pageId: r.pageid,
      title: r.title,
      distanceMeters: r.dist,
      extract: pages[r.pageid]?.extract?.trim() || "",
    }))
    .filter((p) => p.extract.length > 0)
    .sort((a, b) => a.distanceMeters - b.distanceMeters);
}
