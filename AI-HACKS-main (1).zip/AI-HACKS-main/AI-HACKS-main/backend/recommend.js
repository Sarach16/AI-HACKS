import { anthropic } from "./anthropicClient.js";
import { RECOMMENDER_SYSTEM_PROMPT, buildRecommendationUserPrompt } from "./recommenderPrompt.js";

export async function recommendFromPlaces({ category, places, locationLabel }) {
  if (!places?.length) {
    return `I couldn't find any ${category === "food" ? "restaurants" : category === "drink" ? "bars or cafes" : "attractions"} nearby — you might be somewhere off the map, or worth widening the search radius.`;
  }

  const message = await anthropic.messages.create({
    model: "claude-sonnet-4-6",
    max_tokens: 300,
    system: RECOMMENDER_SYSTEM_PROMPT,
    messages: [
      { role: "user", content: buildRecommendationUserPrompt({ category, places, locationLabel }) },
    ],
  });

  return message.content
    .filter((block) => block.type === "text")
    .map((block) => block.text)
    .join("\n")
    .trim();
}
