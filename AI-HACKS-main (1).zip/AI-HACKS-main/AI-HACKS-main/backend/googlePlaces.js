// Thin wrapper around two separate Google Maps Platform APIs:
//   - Geocoding API      (address/place name -> lat/lng)
//   - Places API (New)   (lat/lng -> nearby restaurants/bars/attractions)
// Both need GOOGLE_MAPS_API_KEY. Enable "Geocoding API" and "Places API (New)"
// for that key in Google Cloud Console.

const GEOCODE_URL = "https://maps.googleapis.com/maps/api/geocode/json";
const NEARBY_URL = "https://places.googleapis.com/v1/places:searchNearby";

// Maps our app-level categories to Places API (New) "includedTypes".
// Full type list: https://developers.google.com/maps/documentation/places/web-service/place-types
export const CATEGORIES = {
  food: ["restaurant"],
  drink: ["bar", "cafe"],
  things_to_do: ["tourist_attraction", "museum", "park", "art_gallery"],
};

const FIELD_MASK = [
  "places.displayName",
  "places.formattedAddress",
  "places.rating",
  "places.userRatingCount",
  "places.priceLevel",
  "places.primaryType",
  "places.currentOpeningHours.openNow",
  "places.location",
].join(",");

/**
 * Turns a free-text location ("near Telegraph and Dwight, Berkeley") into
 * coordinates. Used by the MCP tools, where Poke only has text, not GPS.
 */
export async function geocodeLocation(query) {
  if (!process.env.GOOGLE_MAPS_API_KEY) {
    throw new Error("GOOGLE_MAPS_API_KEY is not set");
  }

  const params = new URLSearchParams({
    address: query,
    key: process.env.GOOGLE_MAPS_API_KEY,
  });

  const res = await fetch(`${GEOCODE_URL}?${params}`);
  if (!res.ok) throw new Error(`Geocoding request failed: ${res.status}`);
  const data = await res.json();

  if (data.status !== "OK" || !data.results?.length) {
    throw new Error(`Could not find a location for "${query}" (${data.status})`);
  }

  const { lat, lng } = data.results[0].geometry.location;
  return { lat, lng, formattedAddress: data.results[0].formatted_address };
}

/**
 * Nearby Search (New). category must be a key of CATEGORIES.
 */
export async function searchNearbyPlaces({ lat, lng, radiusMeters = 1000, category = "food", limit = 8 }) {
  if (!process.env.GOOGLE_MAPS_API_KEY) {
    throw new Error("GOOGLE_MAPS_API_KEY is not set");
  }

  const includedTypes = CATEGORIES[category];
  if (!includedTypes) {
    throw new Error(`Unknown category "${category}". Valid: ${Object.keys(CATEGORIES).join(", ")}`);
  }

  const res = await fetch(NEARBY_URL, {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      "X-Goog-Api-Key": process.env.GOOGLE_MAPS_API_KEY,
      "X-Goog-FieldMask": FIELD_MASK,
    },
    body: JSON.stringify({
      includedTypes,
      maxResultCount: Math.min(limit, 20),
      locationRestriction: {
        circle: { center: { latitude: lat, longitude: lng }, radius: Math.min(radiusMeters, 10000) },
      },
      rankPreference: "POPULARITY",
    }),
  });

  if (!res.ok) {
    const body = await res.text();
    throw new Error(`Places API error ${res.status}: ${body}`);
  }

  const data = await res.json();
  const places = data.places ?? [];

  return places.map((p) => ({
    name: p.displayName?.text ?? "Unknown",
    address: p.formattedAddress ?? "",
    rating: p.rating ?? null,
    ratingCount: p.userRatingCount ?? 0,
    priceLevel: p.priceLevel ?? null, // e.g. "PRICE_LEVEL_MODERATE"
    primaryType: p.primaryType ?? "",
    openNow: p.currentOpeningHours?.openNow ?? null,
    lat: p.location?.latitude,
    lng: p.location?.longitude,
  }));
}
