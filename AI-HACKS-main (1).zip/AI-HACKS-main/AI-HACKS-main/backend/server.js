import express from "express";
import cors from "cors";
import dotenv from "dotenv";
import { narratePlace } from "./narrate.js";
import { recommendFromPlaces } from "./recommend.js";
import { searchNearbyPlaces, CATEGORIES } from "./googlePlaces.js";
import { registerMcpRoutes } from "./mcpServer.js";

dotenv.config();

const app = express();
app.use(cors());
app.use(express.json());

if (!process.env.ANTHROPIC_API_KEY) {
  console.warn("[warn] ANTHROPIC_API_KEY is not set — /api/narrate and /api/recommend will fail.");
}
if (!process.env.DEEPGRAM_API_KEY) {
  console.warn("[warn] DEEPGRAM_API_KEY is not set — /api/speak will fail.");
}
if (!process.env.GOOGLE_MAPS_API_KEY) {
  console.warn("[warn] GOOGLE_MAPS_API_KEY is not set — /api/places and Poke recommendations will fail.");
}

/**
 * POST /api/narrate
 * body: { placeName, extract, distanceMeters }
 * returns: { script }
 *
 * Rewrites a raw Wikipedia extract into a short spoken-style narration.
 */
app.post("/api/narrate", async (req, res) => {
  const { placeName, extract, distanceMeters } = req.body;

  if (!placeName || !extract) {
    return res.status(400).json({ error: "placeName and extract are required" });
  }

  try {
    const script = await narratePlace({ placeName, extract, distanceMeters: distanceMeters ?? 0 });
    res.json({ script });
  } catch (err) {
    console.error("narrate error:", err);
    res.status(500).json({ error: "Failed to generate narration" });
  }
});

/**
 * POST /api/places
 * body: { lat, lng, category, radiusMeters? }
 * returns: { places }
 *
 * category is one of "food" | "drink" | "things_to_do". Proxies Google
 * Places API (New) Nearby Search — kept server-side because it needs a
 * billable API key that can't live in the frontend bundle.
 */
app.post("/api/places", async (req, res) => {
  const { lat, lng, category, radiusMeters } = req.body;

  if (lat == null || lng == null || !category) {
    return res.status(400).json({ error: "lat, lng, and category are required" });
  }
  if (!CATEGORIES[category]) {
    return res.status(400).json({ error: `category must be one of: ${Object.keys(CATEGORIES).join(", ")}` });
  }

  try {
    const places = await searchNearbyPlaces({ lat, lng, category, radiusMeters: radiusMeters ?? 1200 });
    res.json({ places });
  } catch (err) {
    console.error("places error:", err);
    res.status(500).json({ error: "Failed to fetch nearby places" });
  }
});

/**
 * POST /api/recommend
 * body: { category, places, locationLabel? }
 * returns: { script }
 *
 * Rewrites raw Places results into a short spoken/text-style recommendation.
 * Kept separate from /api/places so the frontend can show raw place cards
 * AND get a narrated version without re-fetching Places.
 */
app.post("/api/recommend", async (req, res) => {
  const { category, places, locationLabel } = req.body;

  if (!category || !Array.isArray(places)) {
    return res.status(400).json({ error: "category and places[] are required" });
  }

  try {
    const script = await recommendFromPlaces({ category, places, locationLabel });
    res.json({ script });
  } catch (err) {
    console.error("recommend error:", err);
    res.status(500).json({ error: "Failed to generate recommendation" });
  }
});

// Lets Poke (or any MCP client) call recommend_nearby / narrate_location.
// See backend/mcpServer.js, and the README for how to connect this to Poke.
registerMcpRoutes(app);

/**
 * POST /api/speak
 * body: { text }
 * returns: audio/mpeg stream
 *
 * Converts narration script to audio using Deepgram Aura TTS.
 */
app.post("/api/speak", async (req, res) => {
  const { text } = req.body;

  if (!text) {
    return res.status(400).json({ error: "text is required" });
  }

  try {
    const dgResponse = await fetch(
      "https://api.deepgram.com/v1/speak?model=aura-2-thalia-en&encoding=mp3",
      {
        method: "POST",
        headers: {
          Authorization: `Token ${process.env.DEEPGRAM_API_KEY}`,
          "Content-Type": "application/json",
        },
        body: JSON.stringify({ text }),
      }
    );

    if (!dgResponse.ok) {
      const errBody = await dgResponse.text();
      console.error("Deepgram error:", dgResponse.status, errBody);
      return res.status(502).json({ error: "TTS provider error" });
    }

    res.setHeader("Content-Type", "audio/mpeg");
    const buffer = Buffer.from(await dgResponse.arrayBuffer());
    res.send(buffer);
  } catch (err) {
    console.error("speak error:", err);
    res.status(500).json({ error: "Failed to synthesize audio" });
  }
});

app.get("/api/health", (_req, res) => res.json({ ok: true }));

const PORT = process.env.PORT || 3001;
app.listen(PORT, () => console.log(`Backend listening on http://localhost:${PORT}`));
