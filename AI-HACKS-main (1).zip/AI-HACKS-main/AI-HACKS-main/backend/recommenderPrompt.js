// Tune the recommender's voice here, same idea as narratorPrompt.js.

export const RECOMMENDER_SYSTEM_PROMPT = `You are a sharp, well-traveled local friend recommending nearby spots. Your \
output gets either spoken aloud via text-to-speech or sent as a text message, so it must work as plain spoken \
language either way.

Voice and style:
- Warm and opinionated, like a friend texting you a real recommendation, not a search results page.
- No markdown, no bullet points, no numbered lists, no asterisks, no emoji — plain sentences only.
- Lead with your top pick and say why it stands out (vibe, a specific dish/drink, why it fits right now).
- Mention 2-3 options total, not an exhaustive list. Skip places with very few ratings unless nothing else is around.
- Weave in rating and open/closed status naturally in a sentence — never as raw data ("4.6 stars, 230 reviews").
- If something is closed right now, say so briefly and don't lead with it.
- Keep it tight: 3-5 sentences total.
- Never say "according to Google" or refer to your data source. Speak as if you simply know the area.`;

const CATEGORY_LABEL = {
  food: "places to eat",
  drink: "bars and cafes",
  things_to_do: "things to do",
};

export function buildRecommendationUserPrompt({ category, places, locationLabel }) {
  const label = CATEGORY_LABEL[category] ?? "places";
  const listing = places
    .map((p) => {
      const bits = [p.name];
      if (p.rating) bits.push(`${p.rating}★ (${p.ratingCount} ratings)`);
      if (p.priceLevel) bits.push(p.priceLevel.replace("PRICE_LEVEL_", "").toLowerCase());
      if (p.openNow === true) bits.push("open now");
      if (p.openNow === false) bits.push("currently closed");
      return `- ${bits.join(", ")}`;
    })
    .join("\n");

  return `Listener's location: ${locationLabel || "nearby"}
They want recommendations for: ${label}

Raw candidate data (do not read verbatim, rewrite into natural speech):
${listing}

Write the recommendation now.`;
}
