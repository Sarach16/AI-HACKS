import { anthropic } from "./anthropicClient.js";
import { NARRATOR_SYSTEM_PROMPT, buildNarrationUserPrompt } from "./narratorPrompt.js";

export async function narratePlace({ placeName, extract, distanceMeters = 0 }) {
  const message = await anthropic.messages.create({
    model: "claude-sonnet-4-6",
    max_tokens: 300,
    system: NARRATOR_SYSTEM_PROMPT,
    messages: [
      { role: "user", content: buildNarrationUserPrompt({ placeName, extract, distanceMeters }) },
    ],
  });

  return message.content
    .filter((block) => block.type === "text")
    .map((block) => block.text)
    .join("\n")
    .trim();
}
