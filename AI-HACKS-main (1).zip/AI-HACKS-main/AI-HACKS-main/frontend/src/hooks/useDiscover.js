import { useCallback, useRef, useState } from "react";
import { fetchNearbyPlaces, fetchRecommendationScript } from "../lib/places";
import { speakText } from "../lib/audio";

export function useDiscover(position) {
  const [category, setCategory] = useState(null); // "food" | "drink" | "things_to_do" | null
  const [status, setStatus] = useState("idle"); // idle | searching | recommending | speaking | error
  const [result, setResult] = useState(null); // { category, script, places }
  const [errorMessage, setErrorMessage] = useState(null);

  const audioRef = useRef(null);

  const discover = useCallback(
    async (chosenCategory) => {
      if (!position) {
        setErrorMessage("Waiting for your location first.");
        setStatus("error");
        return;
      }

      setCategory(chosenCategory);
      setErrorMessage(null);
      setResult(null);

      try {
        setStatus("searching");
        const places = await fetchNearbyPlaces({
          lat: position.lat,
          lng: position.lng,
          category: chosenCategory,
        });

        setStatus("recommending");
        const script = await fetchRecommendationScript({ category: chosenCategory, places });

        setResult({ category: chosenCategory, script, places });

        setStatus("speaking");
        await speakText(script, audioRef);
        setStatus("idle");
      } catch (err) {
        console.error(err);
        setErrorMessage(err.message || "Something went wrong finding recommendations");
        setStatus("error");
      }
    },
    [position]
  );

  return { category, status, result, errorMessage, discover };
}
