# Wayfarer

A walking guide that watches your location, finds nearby places of interest via
Wikipedia, rewrites the facts into a short spoken narration with Claude, and
speaks it aloud with Deepgram Aura. It also recommends nearby food, drinks,
and things to do via Google Maps, voiced the same way. The same recommendation
and narration logic is exposed as an MCP server so you can connect it to
**Poke** and get it as a text message instead of (or alongside) the voice app.

## Stack

- **Frontend:** React + Vite, plain CSS (no framework)
- **Geolocation:** Browser Geolocation API (`watchPosition`)
- **Place discovery (stories):** Wikipedia Geosearch API (keyless, CORS-enabled, called
  directly from the browser)
- **Place discovery (recommendations):** Google Places API (New) + Geocoding API, proxied
  through the backend (needs a billable key)
- **Narration/recommendation writing:** Claude (`claude-sonnet-4-6`), via a small Express backend
- **Text-to-speech:** Deepgram Aura, via the same backend
- **Text channel:** Poke, via an MCP server the backend exposes at `/mcp`

## Why there's a backend at all

The Geolocation and Wikipedia calls run entirely client-side — no secrets
involved. But the Claude, Deepgram, and Google Maps calls all need API keys, and
API keys can never live in frontend code (anyone can read your bundle's network
requests and steal them). So `backend/` is a minimal Express server that proxies
those calls and holds the real secrets in environment variables.

## Project layout

```
walking-guide/
├── backend/
│   ├── server.js              Express app: /api/narrate, /api/places, /api/recommend,
│   │                          /api/speak, /api/health, /mcp
│   ├── narratorPrompt.js      Story-narrator personality — tune here
│   ├── recommenderPrompt.js   Recommendation personality — tune here
│   ├── narrate.js             Wikipedia extract -> spoken story (Claude)
│   ├── recommend.js           Places results -> spoken/text recommendation (Claude)
│   ├── wikipedia.js           Server-side Wikipedia geosearch (used by the MCP tool)
│   ├── googlePlaces.js        Geocoding + Places API (New) nearby search
│   ├── mcpServer.js           MCP server (recommend_nearby, narrate_location) — connect this to Poke
│   └── .env.example
└── frontend/
    ├── src/
    │   ├── lib/
    │   │   ├── geo.js          Haversine distance helper
    │   │   ├── wikipedia.js    Geosearch + extracts client
    │   │   ├── places.js       Backend Places/recommend client
    │   │   └── audio.js        Shared /api/speak fetch+play helper
    │   ├── hooks/
    │   │   ├── useGeolocation.js   Wraps watchPosition lifecycle
    │   │   ├── useWalkingGuide.js  Orchestrates the passive narration pipeline
    │   │   └── useDiscover.js      On-demand food/drink/things-to-do recommendations
    │   ├── App.jsx
    │   └── App.css
    └── .env.example
```

## Setup

**Backend:**
```bash
cd backend
cp .env.example .env
# fill in ANTHROPIC_API_KEY, DEEPGRAM_API_KEY, and GOOGLE_MAPS_API_KEY in .env
npm install
npm run dev
```

**Frontend** (separate terminal):
```bash
cd frontend
cp .env.example .env   # only needed if backend isn't on localhost:3001
npm install
npm run dev
```

Open the printed localhost URL. Your browser will prompt for location
permission — accept it, or nothing will happen.

### Testing on a phone

Geolocation accuracy on a laptop (wifi-triangulated) is often hundreds of
meters off, which makes this app pretty unconvincing in dev. To actually test
it like a walking guide, run it on your phone:

1. Geolocation requires HTTPS (or `localhost`) — a plain `http://<lan-ip>:5173`
   from your phone will likely be blocked.
2. Easiest fix: tunnel the Vite dev server with something like `ngrok http 5173`
   and open the HTTPS tunnel URL on your phone.
3. Point `VITE_BACKEND_URL` at a similarly tunneled backend, or deploy the
   backend somewhere reachable.

### Google Maps setup

You need one API key with two APIs enabled, in [Google Cloud Console](https://console.cloud.google.com/):
1. **Geocoding API** — turns a text location ("Telegraph and Dwight, Berkeley") into lat/lng. Only used by the Poke/MCP tools, since Poke has no GPS.
2. **Places API (New)** — Nearby Search for restaurants, bars/cafes, and attractions. Used by both the frontend's "What's around" buttons and the MCP tools.

Restrict the key (HTTP referrer or IP) once you've confirmed it works, since this key lives server-side anyway.

### Connecting to Poke (text-message channel)

The backend exposes the same recommendation/narration logic as an MCP server at
`POST /mcp` (tools: `recommend_nearby`, `narrate_location`). Poke can call this
directly, so you can text Poke "recommend a coffee shop near Shattuck and
University" and get an answer without opening the app at all.

To connect it during development:
```bash
# from anywhere, with your backend already running on :3001
npx poke@latest tunnel http://localhost:3001/mcp -n "Wayfarer" --recipe
```
This prints a link/QR code — open it, and it creates the integration in your
Poke account (Kitchen → Integrations). Keep the tunnel process running; if you
stop it, the connection goes offline. For something always-on, deploy
`backend/` somewhere with a public HTTPS URL (Render, Fly.io, etc.) and add it
as an MCP server directly in Kitchen instead of tunneling.

Once connected, go to **Kitchen** and create a Recipe that uses the Wayfarer
integration, with instructions like: *"When I ask for food, drinks, or things
to do near somewhere, use the recommend_nearby tool. When I ask about the
history or story of a place, use narrate_location."* Poke will then call your
backend's Google Maps + Claude pipeline and text you back the result — same
brain as the voice app, different output channel.

Note: this only covers Poke calling *into* your tools. Poke's own replies
still arrive as a normal text message (iMessage/SMS/Telegram/WhatsApp,
whichever you connected) — there's no API to read Poke's replies back out
programmatically, so the voice (Deepgram) and text (Poke) paths are two
separate front doors to the same backend, not one feeding the other.



## How the narration loop works

1. `useGeolocation` keeps a live `watchPosition` subscription and exposes the
   latest coordinates.
2. `useWalkingGuide` watches for position updates, but only acts when **both**
   gates pass: the user moved at least `MIN_MOVE_METERS` since the last check,
   and at least `MIN_SECONDS_BETWEEN_CHECKS` have elapsed. This stops the app
   from hammering Wikipedia on every GPS jitter.
3. When triggered, it queries Wikipedia Geosearch for nearby geotagged
   articles within `SEARCH_RADIUS_METERS`, fetches plain-text summaries for
   them in one batched call, and picks the closest one that's within
   `NARRATE_WITHIN_METERS` and not on cooldown (`RE_NARRATE_COOLDOWN_MS` —
   default 30 min — so it won't repeat the same spot if you loop back).
4. That place's raw Wikipedia extract is sent to `/api/narrate`, where Claude
   rewrites it into a short spoken-style script using the system prompt in
   `narratorPrompt.js`.
5. The script is sent to `/api/speak`, which calls Deepgram Aura and streams
   back an MP3, which the browser plays via the `Audio` API.
6. Status (`idle` / `searching` / `narrating` / `speaking`) and a running
   history of narrated places drive the UI.

All the tuning constants live at the top of `useWalkingGuide.js`:

| Constant | Default | Effect |
|---|---|---|
| `SEARCH_RADIUS_METERS` | 400 | How far out to look for Wikipedia places |
| `MIN_MOVE_METERS` | 40 | Minimum movement before re-checking |
| `MIN_SECONDS_BETWEEN_CHECKS` | 8 | Throttle on Wikipedia queries |
| `NARRATE_WITHIN_METERS` | 60 | How close you must be to actually trigger narration |
| `RE_NARRATE_COOLDOWN_MS` | 30 min | How long before a place can be re-narrated |

## Known limitations / things to expect

- **Wikipedia coverage is sparse.** Only geotagged articles show up — mostly
  landmarks, notable buildings, parks. Expect long quiet stretches in ordinary
  residential streets. This is the single biggest gap between "demo" and
  "actually useful everywhere" — a real product would likely blend in another
  source (OpenStreetMap POIs, a custom places database) for coverage between
  landmarks.
- **GPS accuracy varies a lot**, especially indoors or downtown with tall
  buildings. The `accuracy` field from the Geolocation API is shown in the
  footer so you can sanity-check it.
- **No interruption/conversation yet** — this build is intentionally passive
  narration only. The pipeline (`useWalkingGuide`) is kept separate from the
  UI specifically so a chat/voice layer could be added later without
  rewriting the location or narration logic.
- **Audio autoplay:** browsers restrict autoplay before any user gesture. You
  may need one tap/click on the page before the first narration will actually
  produce sound — this is standard browser policy, not a bug.
- **Cost shape:** each narrated place costs one Claude call + one Deepgram
  call. At the default tuning this is infrequent (gated by both distance and
  cooldown), but a long walk through a dense historic district could trigger
  many in a row — worth keeping an eye on usage if that matters to you.
